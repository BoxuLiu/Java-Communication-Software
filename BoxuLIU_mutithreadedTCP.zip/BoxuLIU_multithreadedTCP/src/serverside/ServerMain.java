package serverside;

import java.io.IOException;

/**
 * Starts a server
 * 
 * @author BoxuLIU
 */
public class ServerMain {
	public static void main(String[] args) {
		try {
			new Server();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}