package serverside;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;

/**
 * @author BoxuLIU
 * Set a thread to make a server to receive date and time
 */
public class Server{
	private ServerSocket serverSocket;
//	create a file at current directory named clientlog
	public static File file = new File("clientlog");
	public static int finish = 0;
	public static boolean closeSocket = false;
	
	/**
	 * Constructor, initiate serverSocket
	 * @throws IOException serverSocket can not be initiated
	 */
	public Server() throws IOException {
		serverSocket = new ServerSocket(3214);
		int ID = 100000;
		System.out.println("Server start succeed!!!");
		stopAllThreads();
		while (Server.closeSocket == false && ID < 100020) {
			Connection connection = new Connection(serverSocket.accept());
			connection.setName(Integer.toString(ID));
			connection.start();
			ID++;
		}
	}
	
	/**
	 * Stop all subThreads and sockets if all the client sending are over
	 */
	public void stopAllThreads() {
		new Thread() {
			public void run() {
				while(finish < 20) {
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				try {
					closeSocket = true;
					serverSocket.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}.start();
	}
	
}
