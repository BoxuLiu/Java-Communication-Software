package serverside;


import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.sql.Date;
import java.text.SimpleDateFormat;

import clientside.Packed;

/**
 * @author BoxuLIU
 * Instantiate this class to build a connection between the listeningSocket and the file
 */
public class Connection extends Thread{
	private Socket listeningSocket;
	private ObjectInputStream reader;
	private PrintStream writer;
	
	private Packed pack;
	private SimpleDateFormat formatter;
	private Date date;
	private String log;
	
	/**
	 * Constructor, to create connection object
	 * @param socket the socket create by controller
	 */
	public Connection(Socket socket) {
		super();
		try {
			listeningSocket = socket;
			reader = new ObjectInputStream(listeningSocket.getInputStream());
			writer = new PrintStream(new FileOutputStream(Server.file,true));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		formatter= new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		date = new Date(System.currentTimeMillis());
		
	}
	
	/**
	 * Judge and print the message from client
	 */
	@Override
	public void run() {
		try {
			int count = 0;
			while(Server.closeSocket == false) {
				if ((pack = (Packed) reader.readObject()) != null) {
					if(pack.signal.equals(Packed.TIME)) {
						log = "client with ID:" + Thread.currentThread().getName() + " connected at " + formatter.format(date) + " and sent timestamp " + pack.info;
						writer.println(log);
						System.out.println(log);
					}
					else if(pack.signal.equals(Packed.END)) {
						log = "client with ID:" + Thread.currentThread().getName() + " disconnected after " + count + " messages at " + formatter.format(new Date(System.currentTimeMillis())) + "<<<END!";
						writer.println(log);
						System.out.println(log);
						Server.finish++;
						break;
					}
					else if(pack.signal.equals(Packed.ERRO)) {
						log = "client with ID:" + Thread.currentThread().getName() + " connected at " + formatter.format(date) + " and sent erro " + pack.info;
						writer.println(log);
						System.out.println(log);
					}
					else {
						throw new IOException("There is no type suit for this pack signal");
					}	
					count++;
	            }
			}
			reader.close();
			writer.close();
			listeningSocket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
