package clientside;

import java.io.IOException;

/**
 * Starts a client
 * 
 * @author BoxuLIU
 */
public class ClientMain {
	public static void main(String[] args) {
		for(int i = 0;i < 20;i++){
			try {
				new Client().start();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}
