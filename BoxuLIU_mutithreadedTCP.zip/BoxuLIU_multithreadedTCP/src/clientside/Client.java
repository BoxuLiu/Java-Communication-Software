package clientside;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Random;

/**
 * Set a thread to make a client to send date and time
 * @author BoxuLIU
 */
public class Client extends Thread{
	private Socket clientSocket;
	private ObjectOutputStream writer;
	

	/**
	 * Constructor, initiate clientSocket and writer
	 * @throws IOException clientSocket can not be initiated
	 */
	public Client() throws IOException {
		clientSocket = new Socket(InetAddress.getLocalHost().getHostAddress(),3214);
		writer = new ObjectOutputStream(clientSocket.getOutputStream());
	}
	
	/**
	 * Send the date and time, after that close client socket
	 */
	@Override
	public void run() {
		try {
			sendTime();
			clientSocket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	/**
	 * Send date and time to client 10~90 times
	 * @throws IOException clientSocket can not send message
	 * @throws InterruptedException clientSocket thread interrupted
	 */
	private void sendTime() throws IOException, InterruptedException {
		SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		for(int i = (new Random()).nextInt(90) + 10;i > 0;i--) {
			writer.writeObject(new Packed(Packed.TIME,formatter.format(new Date(System.currentTimeMillis())) + "*"));
			Thread.sleep(500);
		}
		
		writer.writeObject(new Packed(Packed.END,""));
	}
	
}
