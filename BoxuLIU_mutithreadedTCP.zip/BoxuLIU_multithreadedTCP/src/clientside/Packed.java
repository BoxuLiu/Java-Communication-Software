package clientside;

import java.io.Serializable;

/**
 * In this program, client and server transmit message with objects(Packed) which includes a signal and message
 * The signal is to determine whether the message a erro message, a time message, or end message
 * This class is the class of transmitted content
 * @author Boxu LIU
 */
public class Packed implements Serializable{
	
	public final static Byte TIME = 0; 
	public final static Byte END = 1;
	public final static Byte ERRO = 2;

	public Byte signal;
	public String info;
	
	/**
	 * Constructor, build a Packed with a signal and information
	 * @param signal the indicator determine whether the message a erro message, a time message, or end message
	 * @param info the message send and receive
	 */
	public Packed(Byte signal, String info){
		this.signal = signal;
		this.info = info;
	}
}
