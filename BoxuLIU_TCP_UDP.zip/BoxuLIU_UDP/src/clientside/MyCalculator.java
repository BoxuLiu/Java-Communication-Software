package clientside;

import java.util.ArrayList;
import java.util.Stack;

/**
 * This class provides static methods to calculate the formula in String and return a complete formula 
 * @author BoxuLIU
 */
public class MyCalculator {

	 /**
	  * Calculate the formula and combine the result with formula
	 * @param obj the formula need to be calculated
	 * @return calculated formula
	 */
	public static String calculate(String obj) {	 
		return obj + "=" + Integer.toString(calculator(strFormat(obj)));
	 }
	
	 /**
	  * Calculate the formula into result in int
	 * @param obj the formula in ArrayList
	 * @return the calculated result
	 */
	private static int calculator(ArrayList<String> obj) {
		 ArrayList<String> result = transform(obj);
//		 System.out.println(result);
		 Stack<Integer> stack = new Stack<>();
		 for (int i = 0; i < result.size(); i++) {
			  String symbol = result.get(i);
			  if (isDigital(symbol)) { 
				  stack.push(Integer.parseInt(symbol));
			  } 
			  else { 
				  int num1, num2;
				  num1 = stack.pop(); 
				  num2 = stack.pop();
				  switch (symbol) {
					   case "+":
					   stack.push(num2 + num1);
					   break;
					   case "-":
					   stack.push(num2 - num1);
					   break;
					   case "*":
					   stack.push(num2 * num1);
					   break;
					   case "/":
					   stack.push(num2 / num1);
					   break;
					   default:
					   break;
				  }
			  }
		 }
		 return stack.pop();
	 }
	 
	 /**
	  * Convert middle order traversal to follow-up traversal
	 * @param arrayList arrayList need to be Converted
	 * @return Converted ArrayList
	 */
	private static ArrayList<String> transform(ArrayList<String> arrayList) {
		 Stack<String> stack = new Stack<>();
		 ArrayList<String> result = new ArrayList<>();
		 for (int index = 0; index < arrayList.size(); index++) {
			  String symbol = arrayList.get(index);
			  if (isDigital(symbol)) { 
				  result.add(symbol);
			  } 
			  else if (symbol.equals(")")) {
				  String tmp;
				  while (!(tmp = stack.pop()).equals("(")) {
					  result.add(tmp);
				  }
			  } 
			  else {
				  if (stack.isEmpty()) {
					   stack.push(symbol);
					   continue;
				  }
				  String tmp = stack.peek();
				  while (outPriority(symbol) <= inPriority(tmp)) { 
					   result.add(tmp);
					   stack.pop();
					   if (stack.isEmpty()) {
						   break;
					   }
					   tmp = stack.peek();
				  }
				  stack.push(symbol);
			  }
		 }
		 while (!stack.isEmpty()) {
		  result.add(stack.pop());
		 }
		 return result;
	 }
	 
	 /**
	 * Convert String into ArrayList
	 * @param src String need to be converted
	 * @return ArrayList converted string
	 */
	 private static ArrayList<String> strFormat(String src) {
		 if (src == null || src.equals("")) {
			 return null;
		 }
		 ArrayList<String> arrayList = new ArrayList<>();
		 StringBuilder comChar = new StringBuilder();
		 for (int i = 0; i <src.length(); i++) {
			  char ch = src.charAt(i);
			  if (ch == ' ') {
				  continue; 
			  }
			  if (!Character.isDigit(ch)) {
				  if (!comChar.toString().trim().equals("")) {
					   arrayList.add(comChar.toString().trim());
					   comChar.delete(0, comChar.length());
				  }
				  arrayList.add(ch + "");
				  continue;
			  }
			  comChar.append(ch);
		 }
		 if (!comChar.toString().trim().equals("")) {
			 arrayList.add(comChar.toString().trim());
		 }
		 return arrayList;
	 }
	 
	 /**
	 * Judge whether it is a number
	 * @param symbol the string need to be judged
	 * @return true or false
	 */
	 private static boolean isDigital(String symbol) {
		 return !symbol.equals("+") && !symbol.equals("-")
		  && !symbol.equals("*") && !symbol.equals("/")
		  && !symbol.equals("(") && !symbol.equals(")");
	 }
	 
	 private static int inPriority(String ch) {
		 switch (ch) {
			  case "+":
			  case "-":
			  return 2;
			  case "*":
			  case "/":
			  return 4;
			  case ")":
			  return 7;
			  case "(":
			  return 1;
			  default:
			  return 0;
		 }
	 }
	 
	 private static int outPriority(String ch) {
		 switch (ch) {
			  case "+":
			  case "-":
			  return 3;
			  case "*":
			  case "/":
			  return 5;
			  case ")":
			  return 1;
			  case "(":
			  return 7;
			  default:
			  return 0;
		 }
	 }
	}
