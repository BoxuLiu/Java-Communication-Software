package clientside;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 * @author Boxu LIU
 * Instantiate this class to build a connection between the socket and the buffer(recieveText, sendText)
 */
public class Connection {
	private DatagramSocket listeningSocket;
	private ObjectInputStream reader;
	private ObjectOutputStream writer;
	private Packed pack;
	private ByteArrayInputStream in;
	private ByteArrayOutputStream out;
	private byte[] b = new byte[1024];
	private DatagramPacket recieve = new DatagramPacket(b,b.length);
	private DatagramPacket send;
	private String IP;
	private int port;
	
	/**
	 * Constructor, to create connection object
	 * @param socket the socket create by controller
	 * @param IP the receiver's IP
	 * @param port the receiver's port
	 */
	public Connection(DatagramSocket socket, String IP, int port) {
		super();
		this.IP = IP;
		this.port = port;
		listeningSocket = socket;
		
		this.start();
	}
	
	/**
	 * Start two thread 
	 * 1. Bring the information from socket to buffer(recieveText) continuously
	 * 2. Take the message from buffer(sendText) to socket continuously
	 */
	public void start() {
		new Thread() {
			public void run() {
				try {
					do {
						listeningSocket.receive(recieve);
						in = new ByteArrayInputStream(recieve.getData());
						reader = new ObjectInputStream(in);
						if ((pack = (Packed) reader.readObject())!= null) {
							ClientModel.recieveText.offer(pack);
			            }
						in.reset();
					}while(ClientController.closeSocket == false);
					listeningSocket.close();
					reader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}.start();
		
		new Thread() {
			public void run() {
				do {
					if (!ClientModel.sendText.isEmpty()) {
						try {
							out = new ByteArrayOutputStream();
							writer = new ObjectOutputStream(out);
							writer.writeObject(ClientModel.sendText.poll());
							send = new DatagramPacket(out.toByteArray(),out.toByteArray().length,InetAddress.getByName(IP),port);
							listeningSocket.send(send);
							writer.reset();
							out.reset();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}while(ClientController.closeSocket == false);
				listeningSocket.close();
				try {
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}.start();
		
	}
	
	
}
