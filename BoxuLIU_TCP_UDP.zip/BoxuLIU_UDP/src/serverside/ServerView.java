package serverside;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.swing.*;

import clientside.Packed;

/**
 * View class of server view, generates the GUI
 * @author BoxuLIU
 */
public class ServerView extends JFrame{
	/**
	 * Fields of the view which point to model and controller
	 */
	private ServerModel serverModel = new ServerModel();
	private ServerController servercontroller = new ServerController(this,serverModel);

	public JButton sendButton = new JButton("Send");
	public JButton start = new JButton("Start");
	public JTextArea communicationArea = new JTextArea();{
		
	}
	public JTextField sendField = new JTextField("Hello from client!!!");{
		sendField.setPreferredSize(new Dimension(350,25));
	}
	public JTextField receiverIPField = new JTextField();{
		try {
			String addr = InetAddress.getLocalHost().getHostAddress();
			receiverIPField.setText(addr);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		receiverIPField.setPreferredSize(new Dimension(100,25));
	}
	public JTextField receiverPortField = new JTextField();{
		receiverPortField.setPreferredSize(new Dimension(60,25));
		receiverPortField.setText("6547");
	}
	public JTextField myPortField = new JTextField();{
		myPortField.setPreferredSize(new Dimension(60,25));
		myPortField.setText("4567");
	}
	private JLabel receiverIPLabel = new JLabel("Receiver IP:");
	private JLabel receiverPortLabel = new JLabel("Receiver Port:");
	private JLabel myPortLabel = new JLabel("My Port:");

	/**
	 * Constructor to create a view object
	 * Includes all elements of the GUI and links them to the controller
	 */
	public ServerView() {
		super("Server");
		
		sendButton.addActionListener(servercontroller);
		start.addActionListener(servercontroller);
		this.addWindowListener(servercontroller);
		
		JPanel southPanel = new JPanel();{
			southPanel.add(sendField);
			southPanel.add(sendButton);
		}
		JPanel northPanel = new JPanel();{
			northPanel.add(myPortLabel);
			northPanel.add(myPortField);
			
			northPanel.add(start);
			northPanel.add(new JLabel("  "));
			
			northPanel.add(receiverIPLabel);
			northPanel.add(receiverIPField);

			northPanel.add(receiverPortLabel);
			northPanel.add(receiverPortField);

//			northPanel.add(ConnectButton);
		}
		
		this.add(northPanel,BorderLayout.NORTH);
		this.add(communicationArea,BorderLayout.CENTER);
		this.add(southPanel,BorderLayout.SOUTH);
		this.setSize(550, 500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		communicationShow();
	}
	
	/**
	 * Will be called by the controller when view should be updated,
	 * depack and show all the information from buffer recieveText
	 */
	public void communicationShow() {
		new Thread() {
			public void run() {
				while(true) {
					if (!ServerModel.recieveText.isEmpty()) 
						communicationArea.append(Packed.depack(ServerModel.recieveText.poll()));
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}.start();
	}
}
