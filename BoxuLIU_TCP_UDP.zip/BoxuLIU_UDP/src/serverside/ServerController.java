package serverside;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

import clientside.ClientModel;
import clientside.Packed;

/**
 * Controller class of server, acts as an intermediary between view and model.
 * defines what should happen on user interaction
 * 
 * @author BoxuLIU
 */
public class ServerController extends WindowAdapter implements ActionListener {
	
	/**
	 * Fields of the controller which point to view and model
	 */
	private ServerView serverView;
	private ServerModel serverModel;
	public static boolean closeSocket = false;
	
	/**
	 * Constructor to create controller object
	 * 
	 * @param serverView view object of client which is managed by this controller
	 * @param serverModel model object of client which is managed by this controller
	 */
	ServerController(ServerView serverView, ServerModel serverModel){
		this.serverView = serverView;
		this.serverModel = serverModel;
	}

	/**
	 *Override windowClosing in WindowAdapter to realize the function that close 
	 *all the socket and stream before closing the window
	 */
	public void windowClosing(WindowEvent e) {
		if(serverModel.getClientSocket() != null) {
			serverModel.getClientSocket().close();
			closeSocket = true;
		}
	}
	
	/**
	 * ActionListener, will be called whenever a key on the server view is pressed
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == serverView.sendButton) {
			if(serverModel.getIP() == null || isChanged()) {
				closeExistSocket();
				serverModel.setIP(serverView.receiverIPField.getText());
				serverModel.setPort(Integer.parseInt(serverView.receiverPortField.getText()));
				serverModel.setMyPort(Integer.parseInt(serverView.myPortField.getText()));
				serverModel.setClientSocket();
			}
			ServerModel.sendText.offer(new Packed(Packed.CLIENT,serverView.sendField.getText()));
			ServerModel.recieveText.offer(new Packed(Packed.CLIENT,serverView.sendField.getText()));
			serverView.sendField.setText(null);
		}
		if(e.getSource() == serverView.start) {
			serverModel.setIP(serverView.receiverIPField.getText());
			serverModel.setPort(Integer.parseInt(serverView.receiverPortField.getText()));
			serverModel.setMyPort(Integer.parseInt(serverView.myPortField.getText()));
			serverModel.setClientSocket();
		}
	}
	/**
	 * Judge whether any of receiver IP, receiver port and my port is changed
	 * @return true or false
	 */
	private boolean isChanged() {
		if((serverModel.getIP().contentEquals(serverView.receiverIPField.getText()))&&serverModel.getPort() == Integer.parseInt(serverView.receiverPortField.getText())&&serverModel.getMyPort() == Integer.parseInt(serverView.myPortField.getText())) {
			return false;
		}
		else
			return true;
	}
	
	/**
	 * Close all the existed socket
	 */
	private void closeExistSocket() {
		closeSocket = true;
		try {
			Thread.sleep(100);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		closeSocket = false;
	}
}
