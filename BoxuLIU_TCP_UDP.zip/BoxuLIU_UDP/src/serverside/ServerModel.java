package serverside;

import java.io.*;
import java.net.*;
import java.util.LinkedList;
import java.util.Queue;

import clientside.Packed;

/**
 * Model class for server, holds base calculation functions
 * 
 * @author BoxuLIU
 */
public class ServerModel {
	private String IP;

	private int port;
	private int myPort;
	
	public static Queue<Packed> recieveText;
	public static Queue<Packed> sendText;
	
	private DatagramSocket serverSocket;
	
	/**
	 * Constructor, initiate two buffer(recieveText, sendText) as Queue
	 */
	public ServerModel() {
		recieveText = new LinkedList<Packed>();
		sendText = new LinkedList<Packed>();
	}
	
	public DatagramSocket getServerSocket() {
		return serverSocket;
	}

	public void setServerSocket(DatagramSocket serverSocket) {
		this.serverSocket = serverSocket;
	}
	
	public String getIP() {
		return IP;
	}
	
	public int getPort() {
		return port;
	}

	public int getMyPort() {
		return myPort;
	}

	public void setMyPort(int myPort) {
		this.myPort = myPort;
	}
	
	public DatagramSocket getClientSocket() {
		return serverSocket;
	}

	public void setIP(String iP) {
		IP = iP;
	}

	public void setPort(int port) {
		this.port = port;
	}
	
	/**
	 * Set a socket and connect it to a connection, 
	 * offer a Packed of erro message to the buffer if the function catch any erro
	 */
	public void setClientSocket() {
		new Thread() {
			public void run() {
				try {
					new Connection(new DatagramSocket(myPort),IP,port);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					recieveText.offer(new Packed(Packed.ERRO,e1.toString()));
				}
			}
		}.start();
	}
}
