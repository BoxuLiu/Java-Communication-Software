package clientside;

/**
 * Starts a client
 * 
 * @author BoxuLIU
 */
public class ClientMain {
	public static void main(String[] args) {
		ClientView view = new ClientView();
//		view.setVisible(false);
	}
}
