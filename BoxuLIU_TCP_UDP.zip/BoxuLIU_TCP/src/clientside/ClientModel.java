package clientside;

import java.io.*;
import java.net.*;
import java.util.LinkedList;
import java.util.Queue;

/**
 * Model class for client, holds base calculation functions
 * 
 * @author BoxuLIU
 */
public class ClientModel {
	private String IP;
	private int port;
	
	public static Queue<Packed> recieveText;
	public static Queue<Packed> sendText;
	
	private Socket clientSocket;
	
	/**
	 * Constructor, initiate two buffer(recieveText, sendText) as Queue
	 */
	public ClientModel() {
		recieveText = new LinkedList<Packed>();
		sendText = new LinkedList<Packed>();
	}
	
	public Socket getClientSocket() {
		return clientSocket;
	}

	public void setIP(String iP) {
		IP = iP;
	}

	public void setPort(int port) {
		this.port = port;
	}
	
	/**
	 * Set a socket and connect it to a connection, 
	 * offer a Packed of erro message to the buffer if the function catch any erro
	 */
	public void setClientSocket() {
		new Thread() {
			public void run() {
				try {
					new Connection(new Socket(IP,port));
				} catch (UnknownHostException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					recieveText.offer(new Packed(Packed.ERRO,e1.toString()));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					recieveText.offer(new Packed(Packed.ERRO,e1.toString()));
				}
			}
		}.start();
	}
}
