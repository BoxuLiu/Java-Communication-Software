package clientside;

import java.io.Serializable;

/**
 * In this program, client and server transmit message with objects(Packed) which includes a signal and message
 * The signal is to determine whether the message a erro message and who is the sender
 * This class is the class of transmitted content
 * @author Boxu LIU
 */
public class Packed implements Serializable{
	
	public final static Byte CLIENT = 1;
	public final static Byte SERVER = 2;
	public final static Byte ERRO = 0; 
	public Byte signal;
	public String info;
	
	/**
	 * Constructor, build a Packed with a signal and information
	 * @param signal the indicator determine whether the message a erro message and who is the sender
	 * @param info the message send and receive
	 */
	public Packed(Byte signal, String info){
		this.signal = signal;
		this.info = info;
	}
	
	/**
	 * Translate and extract the information from pack
	 * @param pack the Packed which need to be translated
	 * @return the message in the pack
	 */
	public static String depack(Packed pack) {
		if(pack.signal.equals(Packed.CLIENT))
			return "Client:\n" + pack.info + "\n\n";
		else if(pack.signal.equals(Packed.SERVER))
			return "Server:\n" + pack.info + "\n\n";
		else if(pack.signal.equals(Packed.ERRO))
			return pack.info + "\n\n";
		else
			return "depacked erro!!!\n\n";
	}

	/**
	 * Reverse the message of pack and change the signal to SERVER
	 * @param pack the Packed which need to be reversed
	 * @return the reversed pack
	 */
	public static Packed reverse(Packed pack) {
		pack.info = new StringBuffer(pack.info).reverse().toString();
		pack.signal = SERVER;
		
		return pack;
	}
	
	/**
	 * Copy the pack to an identical new pack
	 * @param pack the pack need to be copied
	 * @return the copy pack
	 */
	public static Packed copy(Packed pack) {
		return new Packed(pack.signal,pack.info);
	}
}
