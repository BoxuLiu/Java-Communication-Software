package clientside;

import java.io.*;
import java.net.Socket;

/**
 * @author Boxu LIU
 * Instantiate this class to build a connection between the socket and the buffer(recieveText, sendText)
 */
public class Connection {
	private Socket listeningSocket;
	private ObjectInputStream reader;
	private ObjectOutputStream writer;
	private Packed pack;
	
	/**
	 * Constructor, to create connection object
	 * @param socket the socket create by controller
	 */
	public Connection(Socket socket) {
		super();
		try {
			listeningSocket = socket;
			writer = new ObjectOutputStream(listeningSocket.getOutputStream());
			reader = new ObjectInputStream(listeningSocket.getInputStream());
			this.start();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Start two thread 
	 * 1. Bring the information from socket to buffer(recieveText) continuously
	 * 2. Take the message from buffer(sendText) to socket continuously
	 */
	public void start() {
		new Thread() {
			public void run() {
				try {
					while(ClientController.closeSocket == false) {
						if ((pack = (Packed) reader.readObject())!= null) {
							ClientModel.recieveText.offer(pack);
			            }
					}
					listeningSocket.close();
					reader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}.start();
		
		new Thread() {
			public void run() {
				while(ClientController.closeSocket == false) {
					if (!ClientModel.sendText.isEmpty()) {
						try {
							writer.writeObject(ClientModel.sendText.poll());
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				try {
					listeningSocket.close();
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}.start();
	}
	
	
}
