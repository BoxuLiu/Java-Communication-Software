package clientside;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

/**
 * Controller class of client, acts as an intermediary between view and model.
 * defines what should happen on user interaction
 * 
 * @author BoxuLIU
 */
public class ClientController extends WindowAdapter implements ActionListener {
	
	/**
	 * Fields of the controller which point to view and model
	 */
	private ClientView clientView;
	private ClientModel clientModel;
	public static boolean closeSocket = false;
	
	/**
	 * Constructor to create controller object
	 * 
	 * @param clientView view object of client which is managed by this controller
	 * @param clientModel model object of client which is managed by this controller
	 */
	ClientController(ClientView clientView, ClientModel clientModel){
		this.clientView = clientView;
		this.clientModel = clientModel;
	}

	/**
	 *Override windowClosing in WindowAdapter to realize the function that close 
	 *all the socket and stream before closing the window
	 */
	@Override
	public void windowClosing(WindowEvent e) {
		if(clientModel.getClientSocket() != null) {
			try {
				clientModel.getClientSocket().close();
				closeSocket = true;
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	/**
	 * ActionListener, will be called whenever a key on the client view is pressed
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == clientView.ConnectButton) {
			clientView.communicationArea.append("connecting to server...\n");
			clientModel.setIP(clientView.IPField.getText());
			clientModel.setPort(Integer.parseInt(clientView.portField.getText()));
			clientModel.setClientSocket();
			ClientModel.sendText.offer(new Packed(Packed.ERRO,"Connection sccuced!!!"));
			clientView.communicationShow();
		}
		if(e.getSource() == clientView.sendButton) {
			ClientModel.sendText.offer(new Packed(Packed.CLIENT,clientView.sendField.getText()));
			ClientModel.recieveText.offer(new Packed(Packed.CLIENT,clientView.sendField.getText()));
			clientView.sendField.setText(null);
		}
	}
	
}
