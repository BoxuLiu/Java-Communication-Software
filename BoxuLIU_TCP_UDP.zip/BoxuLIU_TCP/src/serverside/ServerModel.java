package serverside;

import java.io.IOException;
import java.net.ConnectException;
import java.net.ServerSocket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Queue;
import clientside.Packed;

/**
 * Model class for client, holds base calculation functions
 * 
 * @author BoxuLIU
 */
public class ServerModel {
	
	private int port;
	public static Queue<Packed> recieveText;
	public static Queue<Packed> sendText;
	private ServerSocket serverSocket;
	
	/**
	 * Constructor, initiate two buffer(recieveText, sendText) as Queue
	 */
	public ServerModel() {
		recieveText = new LinkedList<Packed>();
		sendText = new LinkedList<Packed>();
	}
	
	public ServerSocket getServerSocket() {
		return serverSocket;
	}

	public void setPort(int port) {
		this.port = port;
	}
	
	/**
	 * Set a socket and connect it to a connection, 
	 * offer a Packed of erro message to the buffer if the function catch any erro
	 */
	public void setServerSocket() {
		new Thread() {
			public void run() {
				try {
					serverSocket = new ServerSocket(port);
					while (ServerController.closeSocket == false) {
						new Connection(serverSocket.accept());
					}
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					recieveText.offer(new Packed(Packed.ERRO,e.toString()));
				} catch (ConnectException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					recieveText.offer(new Packed(Packed.ERRO,e.toString()));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					recieveText.offer(new Packed(Packed.ERRO,e.toString()));
				};
			}
		}.start();
	}
}

