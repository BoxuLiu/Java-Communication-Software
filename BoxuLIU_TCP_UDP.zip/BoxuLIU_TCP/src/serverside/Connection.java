package serverside;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import clientside.Packed;

/**
 * @author Boxu LIU
 * Instantiate this class to build a connection between the socket and the buffer(recieveText, sendText)
 */
public class Connection {
	private Socket listeningSocket;
	private ObjectInputStream reader;
	private ObjectOutputStream writer;
	private Packed pack;
	
	/**
	 * Constructor, to create connection object
	 * @param socket the socket create by controller
	 */
	public Connection(Socket socket) {
		super();
		try {
			listeningSocket = socket;
			reader = new ObjectInputStream(listeningSocket.getInputStream());
			writer = new ObjectOutputStream(listeningSocket.getOutputStream());
			this.start();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Start two thread 
	 * 1. Bring the information from socket to buffer(recieveText) continuously
	 * 2. Take the message from buffer(sendText) to socket continuously
	 */
	public void start() {
		new Thread() {
			public void run() {
				try {
					while(ServerController.closeSocket == false) {
						if ((pack = (Packed) reader.readObject())!= null) {
							if(!pack.signal.equals(Packed.ERRO)) {
								ServerModel.recieveText.offer(Packed.copy(pack));
								writer.writeObject(Packed.reverse(pack));
							}
							ServerModel.recieveText.offer(pack);
			            }
					}
					listeningSocket.close();
					reader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}.start();
		
		new Thread() {
			public void run() {
				while(ServerController.closeSocket == false) {
					if (!ServerModel.sendText.isEmpty()) {
						try {
							writer.writeObject(ServerModel.sendText.poll());
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				try {
					listeningSocket.close();
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}.start();
	}
}
