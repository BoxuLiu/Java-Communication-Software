package serverside;

/**
 * Starts a server
 * 
 * @author BoxuLIU
 */
public class ServerMain {
	public static void main(String[] args) {
		ServerView view = new ServerView();
	}
}