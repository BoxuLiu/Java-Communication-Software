package rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.LinkedList;

/**
 * The interface of RMI, which offer three functions: saveRecipe, deleteRecipe and getCookbook.
 * 
 * @author BoxuLIU
 */
public interface ICookbook extends Remote {
	boolean saveRecipe(String recipeName, int recipeID, String ingredients, String instructions, String author) throws RemoteException;
	boolean deleteRecipe(String author, int recipeID) throws RemoteException;
	LinkedList<Recipe> getCookbook() throws RemoteException;
}
