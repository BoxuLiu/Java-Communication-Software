package rmi;

import java.io.Serializable;

/**
 * To create recipes which includes: recipeName, recipeID, author, ingredients, instructions.
 * 
 * @author BoxuLIU
 */
public class Recipe implements Serializable {
	
	private String ingredients;
	private String instructions;
	private String recipeName;
	private int recipeID;
	private String author;
	
	/**
	 * Constructor, to initiate the recipe
	 * 
	 * @param recipeName name of recipe
	 * @param recipeID ID of recipe
	 * @param author author name of recipe
	 * @param ingredients ingredients
	 * @param instructions instructions
	 */
	public Recipe(String recipeName, int recipeID, String author, String ingredients, String instructions){
		this.author = author;
		this.ingredients = ingredients;
		this.instructions = instructions;
		this.recipeID = recipeID;
		this.recipeName = recipeName;
	}
	
	public String toString() {
		return "Recipe name: " + recipeName + "\n\n" + "RecipeID: " + recipeID + "\n\n" + "Author: " + author + "\n\n" + "Ingredients: " + "\n" + ingredients + "\n\n" + "Instructions: " + "\n" + instructions;
	}
	
	public String getIngredients() {
		return ingredients;
	}

	public void setIngredients(String ingredients) {
		this.ingredients = ingredients;
	}

	public String getInstructions() {
		return instructions;
	}

	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}

	public String getRecipeName() {
		return recipeName;
	}

	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}

	public int getRecipeID() {
		return recipeID;
	}

	public void setRecipeID(int recipeID) {
		this.recipeID = recipeID;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}
}
