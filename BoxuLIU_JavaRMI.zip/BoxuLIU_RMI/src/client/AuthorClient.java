package client;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import rmi.ICookbook;

/**
 * To create the author client which can call the function of server through RMI ICookbook interface.
 * The default IP is Local address and default port is 3232
 * 
 * @author BoxuLIU
 */
public class AuthorClient {
	
	private ICookbook rmiServer;
	private Registry registry;
	
	/**
	 * Constructor, to initiate a author client
	 * 
	 * @param serverAddress server's address
	 * @param serverPort server's port
	 * @throws NumberFormatException Number Format Exception
	 * @throws RemoteException Remote Exception
	 * @throws NotBoundException Not Bound Exception
	 */
	public AuthorClient(String serverAddress, String serverPort) throws NumberFormatException, RemoteException, NotBoundException {
		registry = LocateRegistry.getRegistry(serverAddress, Integer.parseInt(serverPort));
		rmiServer = (ICookbook) (registry.lookup("rmiServer"));
		UI menu = new UI(rmiServer);
	}
	
	/**
	 * Constructor, to initiate a author client with default value
	 * 
	 * @throws NumberFormatException Number Format Exception
	 * @throws RemoteException Remote Exception 
	 * @throws NotBoundException Not Bound Exception
	 * @throws UnknownHostException Unknown Host Exception
	 */
	public AuthorClient() throws NumberFormatException, RemoteException, NotBoundException, UnknownHostException {
		registry = LocateRegistry.getRegistry(InetAddress.getLocalHost().getHostAddress(), 3232);
		rmiServer = (ICookbook) (registry.lookup("rmiServer"));
		UI menu = new UI(rmiServer);
	}
}

