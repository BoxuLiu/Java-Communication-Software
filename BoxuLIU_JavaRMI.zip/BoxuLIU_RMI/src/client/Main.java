package client;

import java.net.UnknownHostException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;


/**
 * Instantiate author Client to start it up. 
 * The program will detect whether there is a parameter of main and set the configuration automatically
 * 
 * @author BoxuLIU
 */
public class Main {
	public static void main(String args[]) {
		if(args.length >= 2) {
			try {
				AuthorClient a = new AuthorClient(args[0], args[1]);
			} catch (NumberFormatException | RemoteException | NotBoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			try {
				AuthorClient a = new AuthorClient();
			} catch (NumberFormatException | RemoteException | NotBoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
