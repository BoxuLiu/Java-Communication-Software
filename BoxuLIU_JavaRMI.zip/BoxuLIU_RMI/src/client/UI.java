package client;

import java.rmi.RemoteException;
import java.util.LinkedList;
import java.util.Scanner;

import menu.Node;
import rmi.ICookbook;
import rmi.Recipe;

/**
 * Client UI, which is based on tree menu
 * 
 * @author BoxuLIU
 */
public class UI {
	
	private Scanner scanner;
	private ICookbook cookbookServer;
	private LinkedList<Recipe> cookbook;
	
	public UI(ICookbook cookbookServer) throws RemoteException {
		this.cookbookServer = cookbookServer;
		cookbook = cookbookServer.getCookbook();
		scanner = new Scanner(System.in);
		updateRecipeMenu();
		this.enter(this.mainMenu);
	}
	
	/**
	 * Third level menu
	 */
	private LinkedList<Node> allRecipeName = new LinkedList<Node>();
	private LinkedList<Node> allRecipe = new LinkedList<Node>();
	
	
	/**
	 * Secondary menu
	 */
	private Node seeAllRecipeMenu = new Node("See all recipe menu");
	private Node createMenu = new Node("Create Recipe");
	private Node deleteMenu = new Node("Delete Recipe");

	/**
	 * Main menu
	 */
	private Node mainMenu = new Node();{
		mainMenu.addChildren(seeAllRecipeMenu);
		mainMenu.addChildren(createMenu);
		mainMenu.addChildren(deleteMenu);
	}
	
	/**
	 * Get and update the recipe menu from server
	 */
	private void updateRecipeMenu() {
		allRecipeName.clear();
		allRecipe.clear();
		try {
			cookbook = cookbookServer.getCookbook();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		for(int i = 0; i < cookbook.size(); i++) {
			allRecipeName.add(new Node(cookbook.get(i).getRecipeName()));
			allRecipe.add(new Node(cookbook.get(i).toString()));
			allRecipeName.get(i).addChildren(allRecipe.get(i));
		}
		seeAllRecipeMenu.setChildren(allRecipeName);
		
	}
	
	
	
	/**
	 * Read the input and choose the next menu to enter
	 * 
	 * @param menu next menu to enter
	 */
	private void choose(Node menu) {
		int num = scanner.nextInt();
		scanner.nextLine();
		if(num == 0) {
			enter(menu.getParent());
		}
		else {
			for(int i = 0; i < menu.getChildren().size(); i++) {
				if(num == i+1) {
					enter(menu.getChildren().get(i));
					return;
				}
			}
			System.out.println("You have input a wrong number, please try again!\n");
			enter(menu);
		}
	}
	
	/**
	 * Print the menu's options(content) and choose which option to enter.
	 * 
	 * @param menu next menu to enter
	 */
	private void enter(Node menu) {
		if(menu == createMenu) {
			try {
				if(createRecipe()) {
					System.out.println("Create successeed\n");
					updateRecipeMenu();
					enter(menu.getParent());
				}
				else {
					System.out.println("Create failed, the ID may already exist\n");
					enter(menu.getParent());
				}
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}
		else if(menu == deleteMenu) {
			try {
				if(deleteRecipe()) {
					System.out.println("Delete successeed\n");
					updateRecipeMenu();
					enter(menu.getParent());
				}
				else {
					System.out.println("Delete failed, the ID or the arthor name may be wrong\n");
					enter(menu.getParent());
				}
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}
		else if(menu.getChildren().size() == 0) {
			System.out.println("You have input a wrong number, please try again!\n");
			enter(menu.getParent());
		}
		else if(menu.getChildren().size() == 1) {
			System.out.println(menu.getChildren().get(0).getOption());
		}
		
		else {
			System.out.println("Input the corresponding number to enter the menu\n");
			for(int i = 0; i < menu.getChildren().size(); i++) {
				if(menu.getChildren().get(i).getOption().contentEquals("Back")) {
					System.out.println("0. " + menu.getChildren().get(i).getOption());
				}
				else {
					System.out.println(i+1 + ". " + menu.getChildren().get(i).getOption());
				}
			}
		}

		if(menu != mainMenu) {
			System.out.println("\nPut in 0 to go back");
		}
		
		choose(menu);
	}
	
	/**
	 * Create a recipe and save it into server
	 * 
	 * @return whether the creation succeed
	 * @throws RemoteException
	 */
	private boolean createRecipe() throws RemoteException {
		String recipeName;
		int recipeID;
		String ingredients;
		String instructions;
		String author;
		System.out.println("Please put in your recipe name. Put in 0 to exit");
		recipeName = scanner.nextLine();
		if(recipeName.contentEquals("0")) {
			return false;
		}
		System.out.println("Please put in your recipe ID. Put in 0 to exit");
		recipeID = scanner.nextInt();
		scanner.nextLine();
		if(recipeID == 0) {
			return false;
		}
		System.out.println("Please put in author name. Put in 0 to exit");
		author = scanner.nextLine();
		if(author.contentEquals("0")) {
			return false;
		}
		System.out.println("Please put in ingredients. Put in 0 to exit");
		ingredients = scanner.nextLine();
		if(ingredients.contentEquals("0")) {
			return false;
		}
		System.out.println("Please put in instructions. Put in 0 to exit");
		instructions = scanner.nextLine();
		if(instructions.contentEquals("0")) {
			return false;
		}
		return cookbookServer.saveRecipe(recipeName, recipeID, ingredients, instructions, author);
	}
	
	/**
	 * Delete the recipe from server
	 * 
	 * @return whether the deletion succeed
	 * @throws RemoteException
	 */
	private boolean deleteRecipe() throws RemoteException {
		String author;
		int recipeID;
		System.out.println("Please put in author name. Put in 0 to exit");
		author = scanner.nextLine();
		if(author.contentEquals("0")) {
			return false;
		}
		System.out.println("Please put in your recipe ID. Put in 0 to exit");
		recipeID = scanner.nextInt();
		scanner.nextLine();
		if(recipeID == 0) {
			return false;
		}
		return cookbookServer.deleteRecipe(author, recipeID);
	}
}
