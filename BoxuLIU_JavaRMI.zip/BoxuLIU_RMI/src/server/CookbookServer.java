package server;

import java.net.InetAddress;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.LinkedList;

import rmi.ICookbook;
import rmi.Recipe;

/**
 * To create the server of a cook book which can be callback through RMI ICookbook interface.
 * It has three original recipe. And the default port is 3232
 * 
 * @author BoxuLIU
 */
public class CookbookServer extends UnicastRemoteObject implements ICookbook{

	/**
	 * Recipe list which has three original recipe
	 */
	private static LinkedList<Recipe> cookbook = new LinkedList<Recipe>();
	{
		cookbook.add(new Recipe("Sweet and Sour Pork Tenderloin", 10086, "Chef John", "1 (1 1/4 pound) pork tenderloin, trimmed of silver skin\r\n" + 
				"salt and ground black pepper\r\n" + 
				"⅓ cup ketchup\r\n" + 
				"⅓ cup seasoned rice vinegar\r\n" + 
				"1 (8 ounce) can pineapple chunks, drained with juice reserved\r\n" + 
				"2 tablespoons brown sugar\r\n" + 
				"4 cloves garlic, minced\r\n" + 
				"2 teaspoons hot chili sauce (such as Sriracha®)\r\n" + 
				"1 teaspoon soy sauce\r\n" + 
				"1 pinch red pepper flakes\r\n" + 
				"1 tablespoon vegetable oil\r\n" + 
				"1 teaspoon butter\r\n" + 
				"¼ cup chopped green onion (white part only)\r\n" + 
				"2 tablespoons chopped green onion tops", "Step 1\r\n" + 
						"Cut tenderloin into 4 pieces. Arrange in a single layer between two sheets of plastic wrap and pound with a meat mallet until each is about 1-inch thick. Generously season with salt and black pepper.\r\n" + 
						" Step 2\r\n" + 
						"Whisk ketchup, rice vinegar, reserved pineapple juice, brown sugar, garlic, hot chili sauce, soy sauce, and red pepper flakes in a bowl. Set aside.\r\n" + 
						" Step 3\r\n" + 
						"Heat vegetable oil in a skillet over high heat. Place pork in pan; reduce heat to medium. Cook until browned on both sides and cooked through, 5 to 6 minutes per side. Transfer to a plate.\r\n" + 
						" Step 4\r\n" + 
						"Return skillet to medium heat. Stir butter into hot pan. When butter melts and starts to brown, stir in pineapple chunks. Cook, stirring, until pineapple is golden brown, 3 to 4 minutes.\r\n" + 
						" Step 5\r\n" + 
						"Stir in ketchup mixture and 1/4 cup green onion (white parts). Reduce heat to low and simmer until garlic and onion have softened, 5 minutes.\r\n" + 
						" Step 6\r\n" + 
						"Return pork to skillet; cook, stirring, until pork is heated through. Garnish with 2 tablespoons green onion tops."));
		
		cookbook.add(new Recipe("Lion's Head Meatballs", 10010, "Chef John", "1 ½ cups boiling water\r\n" + 
				"1 ounce dried shiitake mushrooms\r\n" + 
				" For the Meatball Mixture:\r\n" + 
				"¼ cup minced canned water chestnuts\r\n" + 
				"1 (8 ounce) container firm tofu, chopped into small bits\r\n" + 
				"1 pound fatty ground pork (at least 20% fat)\r\n" + 
				"¼ cup finely sliced green onions (white and light green parts only)\r\n" + 
				"4 cloves garlic, finely minced\r\n" + 
				"1 ½ teaspoons finely grated peeled fresh ginger\r\n" + 
				"2 tablespoons Shao Hsing rice wine or dry sherry (see Note)\r\n" + 
				"1 tablespoon soy sauce\r\n" + 
				"2 teaspoons kosher salt\r\n" + 
				"¼ teaspoon cayenne pepper\r\n" + 
				"1 tablespoon brown sugar\r\n" + 
				"1 large egg\r\n" + 
				"1 ½ teaspoons cornstarch\r\n" + 
				" For the Cooking Liquid:\r\n" + 
				"1 small head napa cabbage\r\n" + 
				"2 cups chicken broth\r\n" + 
				"2 tablespoons soy sauce\r\n" + 
				"2 tablespoons sherry wine\r\n" + 
				"½ teaspoon sesame oil, or to taste\r\n" + 
				"1 tablespoon brown sugar (optional)\r\n" + 
				"1 ½ teaspoons cornstarch\r\n" + 
				" For the Garnish:\r\n" + 
				"¼ cup sliced green onion tops\r\n" + 
				"2 tablespoons hot chili oil", "Step 1\r\n" + 
						"Pour boiling water over shiitake mushrooms, and let sit until soft enough to slice, about 1 hour.\r\n" + 
						" Step 2\r\n" + 
						"Meanwhile, combine chestnuts and tofu in a large bowl. Add ground pork, green onions, garlic, and ginger. Pour in rice wine, soy sauce, salt, cayenne, brown sugar, and egg. Dust with cornstarch. Mix with a clean hand until thoroughly combined. Cover with plastic wrap and refrigerate for at least 1 hour.\r\n" + 
						" Step 3\r\n" + 
						"Form mixture into 6 large meatballs with wet hands.\r\n" + 
						" Step 4\r\n" + 
						"Set an oven rack about 8 inches from the heat source and preheat the oven's broiler. Line a baking sheet with aluminum foil and oil lightly. Place meatballs on the prepared baking sheet.\r\n" + 
						" Step 5\r\n" + 
						"Broil in the preheated oven until browned, 8 to 10 minutes. Remove from the oven and let cool while prepping the pot.\r\n" + 
						" Step 6\r\n" + 
						"Trim off the bottom of the head of cabbage and slice 1/2 of the head. Arrange sliced cabbage on the bottom of a large soup pot or Dutch oven. Arrange the remaining leaves on the top. Slice and scatter the mushrooms on top of the cabbage; reserve shiitake liquid. Nestle the meatballs into the cabbage leaves and pour juices over.\r\n" + 
						" Step 7\r\n" + 
						"Strain reserved shiitake liquid into a bowl. Add chicken broth, soy sauce, sherry, sesame oil, brown sugar, and cornstarch. Whisk until dissolved. Add to the pot, pouring over each meatball. Bring to a boil over high heat.\r\n" + 
						" Step 8\r\n" + 
						"Reduce heat to medium-low, cover, and cook for 20 minutes. Uncover and raise heat to medium-high. Continue cooking, basting the meatballs often, until liquid reduces slightly and meatballs are no longer pink in the centers, about 10 minutes. Taste for seasoning.\r\n" + 
						" Step 9\r\n" + 
						"Ladle into serving bowls and arrange cabbage over the meatballs. Top with green onions and chili oil."));
		cookbook.add(new Recipe("Chinese Pork Dumplings", 10000, "Allrecipes", "½ cup soy sauce\r\n" + 
				"1 tablespoon seasoned rice vinegar\r\n" + 
				"1 tablespoon finely chopped Chinese chives\r\n" + 
				"1 tablespoon sesame seeds\r\n" + 
				"1 teaspoon chile-garlic sauce (such as Sriracha®)\r\n" + 
				"1 pound ground pork\r\n" + 
				"3 cloves garlic, minced\r\n" + 
				"1 egg, beaten\r\n" + 
				"2 tablespoons finely chopped Chinese chives\r\n" + 
				"2 tablespoons soy sauce\r\n" + 
				"1 ½ tablespoons sesame oil\r\n" + 
				"1 tablespoon minced fresh ginger\r\n" + 
				"50 eaches dumpling wrappers\r\n" + 
				"1 cup vegetable oil for frying\r\n" + 
				"1 quart water, or more as needed", "Step 1\r\n" + 
						"Combine 1/2 cup soy sauce, rice vinegar, 1 tablespoon chives, sesame seeds, and chile sauce in a small bowl. Set aside.\r\n" + 
						" Step 2\r\n" + 
						"Mix pork, garlic, egg, 2 tablespoons chives, soy sauce, sesame oil, and ginger in a large bowl until thoroughly combined. Place a dumpling wrapper on a lightly floured work surface and spoon about 1 tablespoon of the filling in the middle. Wet the edge with a little water and crimp together forming small pleats to seal the dumpling. Repeat with remaining dumpling wrappers and filling.\r\n" + 
						" Step 3\r\n" + 
						"Heat 1 to 2 tablespoons vegetable oil in a large skillet over medium-high heat. Place 8 to 10 dumplings in the pan and cook until browned, about 2 minutes per side. Pour in 1 cup of water, cover and cook until the dumplings are tender and the pork is cooked through, about 5 minutes. Repeat for remaining dumplings. Serve with soy sauce mixture for dipping."));
	}
	private int regPort;
	private String thisAddress;
	private Registry registry; 

	
	/**
	 * Constructor, initiate the server with thisAddress = localAdress and regPort = 3232
	 * @throws RemoteException Remote Exception
	 */
	public CookbookServer() throws RemoteException {
		super();
		
		try {
			thisAddress = (InetAddress.getLocalHost()).toString();
		} catch (Exception e) {
			throw new RemoteException("can't get inet address.");
		}
		
		regPort = 3232; // registry's port
		
		try {
			registry = LocateRegistry.createRegistry(regPort);
			registry.rebind("rmiServer", this);
		} catch (RemoteException e) {
			throw e;
		}
		System.out.println("Server start sccessed\n");
		System.out.println("Address=" + thisAddress + ",port="+regPort);
	}
	
	/**
	 * Lookup the recipe through recipe ID and recipe author
	 * @param author The author of recipe
	 * @param recipeID The ID of recipe
	 * @return The recipe user looking for
	 */
	private Recipe getRecipe(String author, int recipeID) {
		for(int i = 0; i < cookbook.size(); i++) {
			if(cookbook.get(i).getAuthor().contentEquals(author) && cookbook.get(i).getRecipeID() == recipeID) {
				return this.cookbook.get(i);
			}
		}
		return null;
	}
	
	/**
	 *Override from ICookbook interface, to implement the save recipe function
	 */
	@Override
	public boolean saveRecipe(String recipeName, int recipeID, String ingredients, String instructions, String author) {
		if(getRecipe(author, recipeID) == null) {
			cookbook.add(new Recipe(recipeName, recipeID, author, ingredients, instructions));
			System.out.println("ID: " + recipeID + "  Author: " + author + "  Recipe is saved.");
			return true;
		}
		else
			return false;
	}

	/**
	 *Override from ICookbook interface, to implement the delete recipe function
	 */
	@Override
	public boolean deleteRecipe(String author, int recipeID) {
		if(getRecipe(author, recipeID) != null) {
			cookbook.remove(cookbook.indexOf(getRecipe(author, recipeID)));
			System.out.println("ID: " + recipeID + "  Author: " + author + "  Recipe is deleted.");
			return true;
		}
		else
			return false;
	}
	
	/**
	 *Override from ICookbook interface, to implement the get cook book function
	 */
	@Override
	public LinkedList<Recipe> getCookbook() {	
		return cookbook;
	}
	
}
