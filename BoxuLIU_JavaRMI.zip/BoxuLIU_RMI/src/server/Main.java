package server;

/**
 * Instantiate cook book server to start it up.
 * 
 * @author BoxuLIU
 */
public class Main {
	public static void main(String args[]) {
		try {
			CookbookServer s = new CookbookServer();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
}
