package menu;

import java.util.LinkedList;


/**
 * To create a node which can be linked to a parent node and multiple child node to construct a tree data structure.
 * 
 * @author BoxuLIU
 */
public class Node {
	private String option;
	private Node parent;
	private LinkedList<Node> children = new LinkedList<Node>();

	/**
	 * Constructor, to initiate the Node
	 * 
	 * @param option the content of the node
	 * @param parent the parent node
	 * @param children the list of child node
	 */
	public Node(String option, Node parent, LinkedList<Node> children) {
		this.option = option;
		this.parent = parent;
		this.setChildren(children);
	}

	/**
	 * Constructor, to initiate the Node
	 * 
	 * @param option the content of the node
	 * @param children the list of child node
	 */
	public Node(String option, LinkedList<Node> children) {
		this.option = option;
		this.children = children;
		for(int i = 0; i < children.size(); i++) {
			children.get(i).setParent(this);
		}
	}

	/**
	 * Constructor, to initiate the Node
	 * 
	 * @param option the content of the node
	 * @param parent the parent node
	 */
	public Node(String option, Node parent) {
		this.option = option;
		this.parent = parent;
	}

	/**
	 * Constructor, to initiate the Node
	 * 
	 * @param option the content of the node
	 */
	public Node(String option) {
		this.option = option;
	}
	
	/**
	 * Constructor, to initiate the Node
	 */
	public Node() {
	}
	
	

	public String getOption() {
		return option;
	}
	
	public void setOption(String option) {
		this.option = option;
	}

	public Node getParent() {
		return parent;
	}

	public void setParent(Node parent) {
		this.parent = parent;
	}

	public LinkedList<Node> getChildren() {
		return children;
	}

	public void setChild(int index, Node child) {
		children.set(index, child);
		children.get(index).setParent(this);
	}
	
	public void setChildren(LinkedList<Node> children) {
		this.children = children;
		for(int i = 0; i < children.size(); i++) {
			children.get(i).setParent(this);
		}
	}

	/**
	 * Add a single child node to the children list
	 * @param child child node need to be add into children list
	 */
	public void addChildren(Node child) {
		children.add(child);
		child.setParent(this);
	}
}
